"""Frozen-candidate v7 trainer. Running this file trains ONCE; import is read-only."""
import torch,json,random,time,os,collections,copy
from pathlib import Path
from model import NLU
P=Path(__file__).resolve().parent
GRID=[.5,.6,.7,.8,.9,.95,.975,.99,.995,1.0]
def load(n):return list(map(json.loads,(P/'data'/(n+'.jsonl')).read_text().splitlines()))
def pack(rs):
 xs=[torch.tensor(list(r['utt'].encode()))for r in rs];ns=torch.tensor([len(x)for x in xs]);ys=torch.tensor([r['intent_target']for r in rs]);ss=[]
 for r in rs:
  tags=[-100]*len(r['utt'].encode());pos=0
  for ch in r['utt']:
   start=pos;pos+=len(ch.encode())
   if r['slot_loss_enabled']:tags[pos-1]=r['byte_tags'][start]
  ss.append(torch.tensor(tags))
 return torch.nn.utils.rnn.pad_sequence(xs,batch_first=True),ns,ys,torch.nn.utils.rnn.pad_sequence(ss,batch_first=True,padding_value=-100)
def loss_parts(pi,ps,ys,ss):
 il=torch.nn.functional.cross_entropy(pi,ys,reduction='none');valid=ss!=-100
 sl=torch.nn.functional.cross_entropy(ps[valid],ss[valid],reduction='sum')if valid.any()else ps.sum()*0
 return il,sl,int(valid.sum())
def evaluate(m,rs):
 by={k:[]for k in range(4)};slot_sum=0.;tokens=0;correct=0
 with torch.no_grad():
  for j in range(0,len(rs),16):
   x,n,y,s=pack(rs[j:j+16]);pi,ps=m(x,n);il,sl,nt=loss_parts(pi,ps,y,s);slot_sum+=float(sl);tokens+=nt;correct+=int((pi.argmax(-1)==y).sum())
   for k,v in zip(y.tolist(),il.tolist()):by[k].append(v)
 assert all(by.values()),'DEV must contain all 4 classes'
 macro=sum(sum(v)/len(v)for v in by.values())/4;slot=slot_sum/max(tokens,1)
 return {'n':len(rs),'intent_correct':correct,'macro_intent_ce':macro,'positive_slot_token_ce':slot,'selection_objective':macro+slot,'slot_tokens':tokens}
def calibrate(m,rs):
 vals=[]
 with torch.no_grad():
  for j in range(0,len(rs),16):
   x,n,y,s=pack(rs[j:j+16]);pi,_=m(x,n);p=pi.softmax(-1);conf,pred=p.max(-1);vals.extend(zip(conf.tolist(),pred.tolist(),y.tolist()))
 pos=sum(y!=3 for c,p,y in vals);rows=[]
 for t in GRID:
  accepted=[(p,y)for c,p,y in vals if p!=3 and c>=t];covered=sum(y!=3 for p,y in accepted);wrong=sum(p!=y for p,y in accepted);fp=sum(y==3 for p,y in accepted)
  rows.append({'threshold':t,'accepted':len(accepted),'accepted_positive':covered,'positive_coverage':covered/max(pos,1),'accepted_intent_errors':wrong,'negative_false_accepts':fp})
 eligible=[r for r in rows if r['accepted_intent_errors']==0 and r['negative_false_accepts']==0];choice=max(eligible,key=lambda r:(r['positive_coverage'],r['threshold']))
 return {'grid':rows,'selected':choice,'pass':choice['positive_coverage']>=.2,'warning':'Observed calibration errors only, not a safety guarantee; no refit on failure.'}
def main():
 torch.set_num_threads(1);torch.manual_seed(181);random.seed(181);tr=load('train');dv=load('dev');m=NLU();assert sum(p.numel()for p in m.parameters())==82059;o=torch.optim.Adam(m.parameters(),lr=.003);start=time.monotonic();best=float('inf');hist=[];exposure=collections.Counter();variant=collections.Counter();bytes_seen=0
 for step in range(1,1001):
  if time.monotonic()-start>600:raise RuntimeError('600second limit')
  rs=random.sample(tr,16);x,n,y,s=pack(rs);m.train();o.zero_grad();pi,ps=m(x,n);il,sl,nt=loss_parts(pi,ps,y,s);l=il.mean()+sl/max(nt,1);l.backward();torch.nn.utils.clip_grad_norm_(m.parameters(),1);o.step()
  for r in rs:exposure[r['id']]+=1;variant[r['variant']]+=1;bytes_seen+=len(r['utt'].encode())
  if step in [100,300,1000]:
   m.eval();r=evaluate(m,dv);hist.append({'step':step,'dev':r})
   if r['selection_objective']<best:
    best=r['selection_objective'];torch.save({'model':m.state_dict(),'optimizer':o.state_dict(),'torch_rng':torch.get_rng_state(),'python_rng':random.getstate(),'step':step,'source_exposures':dict(exposure),'variant_exposures':dict(variant),'input_bytes_seen':bytes_seen},P/'selected_full.pt.tmp');os.replace(P/'selected_full.pt.tmp',P/'selected_full.pt')
 fit_wall=time.monotonic()-start
 # Restore equality is one disposable update on each of two independent copies, never a selected weight update.
 state=torch.load(P/'selected_full.pt',weights_only=False);copies=[];fixed=pack(tr[:16])
 for _ in range(2):
  a=NLU();a.load_state_dict(state['model']);ao=torch.optim.Adam(a.parameters(),lr=.003);ao.load_state_dict(copy.deepcopy(state['optimizer']));torch.set_rng_state(state['torch_rng']);random.setstate(state['python_rng']);ao.zero_grad();pi,ps=a(fixed[0],fixed[1]);il,sl,nt=loss_parts(pi,ps,fixed[2],fixed[3]);(il.mean()+sl/max(nt,1)).backward();torch.nn.utils.clip_grad_norm_(a.parameters(),1);ao.step();copies.append({k:v.clone()for k,v in a.state_dict().items()})
 assert all(torch.equal(v,copies[1][k])for k,v in copies[0].items())
 m.load_state_dict(state['model']);m.eval();cal=calibrate(m,load('calibration'));result={'selected_step':state['step'],'parameters':82059,'updates':1000,'fit_wall_seconds':fit_wall,'train_variant_rows':len(tr),'source_exposures':dict(exposure),'variant_exposures':dict(variant),'input_bytes_seen':bytes_seen,'history':hist,'calibration':cal,'restore_next_update_equal':True,'no_acceptance_data_read':True};(P/'results.json').write_text(json.dumps(result,indent=2));(P/'operating_point.json').write_text(json.dumps(cal,indent=2));print(json.dumps({k:v for k,v in result.items()if k!='source_exposures'}))
if __name__=='__main__':main()
