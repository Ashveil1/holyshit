"""Greedy inference. Input JSON is a list of [role,text] pairs supplied by caller."""
import sys,json,pathlib
import torch
from model import Generator

def load_checkpoint(path):
 torch.set_num_threads(1);state=torch.load(path,map_location='cpu',weights_only=False);m=Generator();m.load_state_dict(state['model'],strict=True);m.eval();return m,state
if __name__=='__main__':
 m,state=load_checkpoint(sys.argv[1]);turns=json.load(sys.stdin);print(json.dumps(m.generate(turns),ensure_ascii=False))
