import torch
USER,ASSISTANT,BOS,EOS=256,257,258,259
CONFIG={'vocab':260,'embedding':64,'hidden':256,'seed':451,'max_total':1536,'max_reply_bytes':256}
class Generator(torch.nn.Module):
 def __init__(self):
  super().__init__();self.emb=torch.nn.Embedding(260,64);self.gru=torch.nn.GRU(64,256,batch_first=True);self.head=torch.nn.Linear(256,260)
 def forward(self,x,state=None):
  out,state=self.gru(self.emb(x),state);return self.head(out),state
 def generate(self,turns,max_bytes=256):
  tokens=[BOS]
  for role,text in turns:tokens += [USER if role=='USER'else ASSISTANT]+list(text.encode('utf8'))
  tokens += [ASSISTANT]
  if len(tokens)>1536:raise ValueError('CONTEXT_LENGTH_CAP')
  result=[]
  with torch.no_grad():
   logits,h=self(torch.tensor([tokens],dtype=torch.long));n=int(logits[0,-1].argmax())
   for _ in range(max_bytes):
    if n==EOS:break
    if n>255:return {'valid_utf8':False,'reserved_token_generated':n,'byte_length':len(result),'text':None}
    result.append(n);logits,h=self(torch.tensor([[n]]),h);n=int(logits[0,-1].argmax())
  try:text=bytes(result).decode('utf8');valid=True
  except UnicodeDecodeError:text=None;valid=False
  return {'text':text,'valid_utf8':valid,'byte_length':len(result),'terminated_eos':n==EOS}
