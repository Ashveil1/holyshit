import time
FIT_START=time.monotonic()
import sys,pathlib,json,hashlib,random,os,resource

import torch
from model import Generator,USER,ASSISTANT,BOS,EOS,CONFIG
P=pathlib.Path(__file__).resolve().parent;D=pathlib.Path(sys.argv[1]);torch.set_num_threads(1);torch.manual_seed(451);rng=random.Random(451)
manifest=json.loads((D/'train_curation_result.json').read_text());assert hashlib.sha256((D/'train_curation_result.json').read_bytes()).hexdigest()=='af33de181997c11bed7370dd3f4215c04669c70f5e11d8e5284dcd4728c9fd00'
sha=hashlib.sha256()
with (D/'woz-dialogs.json').open('rb')as f:
 for b in iter(lambda:f.read(65536),b''):sha.update(b)
assert sha.hexdigest()=='cd3bc4e968487315d412c044d30af2bf0a4b33c3ef8b74c589f1e1fa832bf72f'
needed={x['conversation_id_hash']for x in manifest['manifest']};objects={};dec=json.JSONDecoder();buf='';i=0;first=True
with (D/'woz-dialogs.json').open()as f:
 while True:
  buf=buf[i:]+f.read(65536);i=0
  if first:i=buf.index('[')+1;first=False
  done=False
  while True:
   while i<len(buf)and(buf[i].isspace()or buf[i]==','):i+=1
   if i<len(buf)and buf[i]==']':done=True;break
   try:o,j=dec.raw_decode(buf,i)
   except json.JSONDecodeError:break
   i=j;ch=hashlib.sha256(o['conversation_id'].encode()).hexdigest()
   if ch in needed:objects[ch]=o
  if done:break
items=[];lengths=[]
for c in manifest['manifest']:
 us=objects[c['conversation_id_hash']]['utterances'];t=c['target_turn_index'];assert us[t]['speaker']=='ASSISTANT';prompt=[BOS]
 for u in us[:t]:prompt += [USER if u['speaker']=='USER'else ASSISTANT]+list(u['text'].encode('utf8'))
 prompt += [ASSISTANT];target=list(us[t]['text'].encode('utf8'))+[EOS];seq=prompt+target
 if len(seq)>1536 or len(target)-1>256:raise RuntimeError('DATA_LENGTH_CONTRACT_FAIL')
 items.append((torch.tensor([seq[:-1]]),torch.tensor([seq[1:]]),len(prompt)-1));lengths.append({'item_hash':hashlib.sha256((c['conversation_id_hash']+':'+str(t)).encode()).hexdigest(),'total_tokens':len(seq),'target_bytes':len(target)-1})
assert len(items)==25
# Only curated sequences retained; erase transient raw objects and parse buffers.
objects.clear();del o,us,buf
m=Generator();assert sum(p.numel()for p in m.parameters())==330756;opt=torch.optim.Adam(m.parameters(),lr=.001,betas=(.9,.999),eps=1e-8,weight_decay=0)
steps=0;epoch=0;order=[];losses=[];snapshots=[];exposure=[0]*25
checkpoint_manifest={'source':'Taskmaster-1 WOz','source_sha256':sha.hexdigest(),'curation_manifest_sha256':'af33de181997c11bed7370dd3f4215c04669c70f5e11d8e5284dcd4728c9fd00','train_items':25,'config':CONFIG}
def save(step,final=False):
 name=f'step-{step}-full.pt';path=P/name
 state={'model':m.state_dict(),'optimizer':opt.state_dict(),'step':step,'seed':451,'python_rng':rng.getstate(),'torch_rng':torch.get_rng_state(),'config':CONFIG,'data_manifest':checkpoint_manifest,'epoch':epoch,'remaining_order':order,'exposure':exposure}
 torch.save(state,path);rawsha=hashlib.sha256(path.read_bytes()).hexdigest();row={'step':step,'file':name,'sha256':rawsha,'bytes':path.stat().st_size,'final':final}
 for old in snapshots:
  if old['step']==step:old.update(row);break
 else:snapshots.append(row)
 (P/'snapshots.json').write_text(json.dumps(snapshots,indent=2))
while steps<1000 and time.monotonic()-FIT_START<590:
 if not order:epoch+=1;order=list(range(25));rng.shuffle(order)
 idx=order.pop();x,y,start=items[idx];opt.zero_grad(set_to_none=True);logits,_=m(x);loss=torch.nn.functional.cross_entropy(logits[:,start:,:].reshape(-1,260),y[:,start:].reshape(-1))
 if not torch.isfinite(loss):raise RuntimeError('NONFINITE_LOSS')
 loss.backward();gn=torch.nn.utils.clip_grad_norm_(m.parameters(),1.)
 if not torch.isfinite(gn):raise RuntimeError('NONFINITE_GRAD')
 opt.step()
 if not all(torch.isfinite(p).all()for p in m.parameters()):raise RuntimeError('NONFINITE_WEIGHTS')
 steps+=1;exposure[idx]+=1;losses.append(float(loss))
 if steps in (100,300,600,1000):save(steps)
 if steps%100==0:print(json.dumps({'step':steps,'elapsed':time.monotonic()-FIT_START,'train_recent_mean':sum(losses[-100:])/100}),flush=True)
save(steps,True)
r={'status':'ONE_FIT_COMPLETE','final_step':steps,'fit_wall_seconds_init_through_save':time.monotonic()-FIT_START,'train_first25_mean':sum(losses[:25])/25,'train_last25_mean':sum(losses[-25:])/25,'exposure_min':min(exposure),'exposure_max':max(exposure),'epochs_started':epoch,'parameters':330756,'data_lengths':lengths,'peak_worker_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,'test_executed':False,'limitations':'25curated naturalprefixes tinytoy; TRAIN loss not conversation/context proof; heldout evaluator separate; no Thai/correction/generalchat claim','checkpoint_manifest':checkpoint_manifest}
(P/'fit_result.json').write_text(json.dumps(r,indent=2));print(json.dumps({k:v for k,v in r.items()if k!='data_lengths'}),flush=True)
