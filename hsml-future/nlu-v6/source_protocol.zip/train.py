import torch,json,random,time,copy,os
from pathlib import Path
from model import NLU
P=Path(__file__).resolve().parent;torch.set_num_threads(1);torch.manual_seed(181);random.seed(181)
def load(n):return list(map(json.loads,((P/'data')/(n+'.jsonl')).read_text().splitlines()))
def pack(rs):
 xx=[torch.tensor(list(r['utt'].encode()))for r in rs];lens=torch.tensor([len(x)for x in xx]);ss=[]
 for r in rs:
  tags=[-100]*len(r['utt'].encode());pos=0
  for ch in r['utt']:
   start=pos;pos+=len(ch.encode());tags[pos-1]=r['byte_tags'][start]
  ss.append(torch.tensor(tags))
 return torch.nn.utils.rnn.pad_sequence(xx,batch_first=True),lens,torch.tensor([r['intent_target']for r in rs]),torch.nn.utils.rnn.pad_sequence(ss,batch_first=True,padding_value=-100)
def loss(m,b):
 x,n,i,s=b;pi,ps=m(x,n);return torch.nn.functional.cross_entropy(pi,i)+torch.nn.functional.cross_entropy(ps.reshape(-1,7),s.reshape(-1),ignore_index=-100)
def evaluate(m,rs):
 totals={'intent_correct':0,'joint_sentence_exact':0,'slot_sequence_exact':0,'n':len(rs)};losses=[]
 with torch.no_grad():
  for j in range(0,len(rs),16):
   b=pack(rs[j:j+16]);pi,ps=m(b[0],b[1]);losses.append(float(loss(m,b))*len(pi))
   for k,r in enumerate(rs[j:j+16]):
    ic=int(pi[k].argmax())==r['intent_target'];mask=b[3][k,:b[1][k]]!=-100;sc=ps[k,:b[1][k]][mask].argmax(-1).tolist()==b[3][k,:b[1][k]][mask].tolist();totals['intent_correct']+=ic;totals['slot_sequence_exact']+=sc;totals['joint_sentence_exact']+=ic and sc
 totals['combined_loss']=sum(losses)/len(rs);return totals
tr=load('train');dv=load('dev');m=NLU()
# Independent baseline class initialization check, preserve subsequent random state.
import importlib.util
spec=importlib.util.spec_from_file_location('baseline_nlu',str(P/'baseline_init.py'));base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base);saved_rng=torch.get_rng_state();torch.manual_seed(181);bm=base.NLU();assert all(torch.equal(v,bm.state_dict()[k])for k,v in m.state_dict().items());torch.set_rng_state(saved_rng);del bm
o=torch.optim.Adam(m.parameters(),lr=.003);start=time.monotonic();hist=[];best=float('inf');exposures=0;bytes_seen=0
for step in range(1,1001):
 if time.monotonic()-start>600:raise RuntimeError('600second limit')
 rs=random.sample(tr,16);batch=pack(rs);m.train();o.zero_grad();l=loss(m,batch);l.backward();torch.nn.utils.clip_grad_norm_(m.parameters(),1);o.step();exposures+=len(rs);bytes_seen+=sum(len(r['utt'].encode())for r in rs)
 if step in [100,300,1000]:
  m.eval();r=evaluate(m,dv);hist.append({'step':step,'dev':r,'examples_seen':exposures,'input_bytes_seen':bytes_seen})
  if r['combined_loss']<best:
   best=r['combined_loss'];torch.save({'model':m.state_dict(),'optimizer':o.state_dict(),'torch_rng':torch.get_rng_state(),'python_rng':random.getstate(),'step':step,'examples_seen':exposures,'input_bytes_seen':bytes_seen},P/'selected_full.pt.tmp');os.replace(P/'selected_full.pt.tmp',P/'selected_full.pt')
s=torch.load(P/'selected_full.pt',weights_only=False);a=NLU();a.load_state_dict(s['model']);oa=torch.optim.Adam(a.parameters(),lr=.003);oa.load_state_dict(s['optimizer']);b=NLU();b.load_state_dict(s['model']);ob=torch.optim.Adam(b.parameters(),lr=.003);ob.load_state_dict(copy.deepcopy(s['optimizer']));fixed=pack(tr[:16])
for mm,oo in [(a,oa),(b,ob)]:
 torch.set_rng_state(s['torch_rng']);random.setstate(s['python_rng']);oo.zero_grad();l=loss(mm,fixed);l.backward();torch.nn.utils.clip_grad_norm_(mm.parameters(),1);oo.step()
assert all(torch.equal(v,b.state_dict()[k])for k,v in a.state_dict().items());m.load_state_dict(s['model']);m.eval()
result={'selected_step':s['step'],'parameters':sum(p.numel()for p in m.parameters()),'updates':1000,'train_examples':len(tr),'dev_examples':len(dv),'exposures':exposures,'input_bytes_seen':bytes_seen,'selected_exposures':s['examples_seen'],'selected_input_bytes_seen':s['input_bytes_seen'],'history':hist,'train':evaluate(m,tr),'dev':evaluate(m,dv),'restore_next_update_equal':True,'wall_seconds':time.monotonic()-start,'no_external_test_read':True};(P/'results.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
