import torch
from torch import nn
INTENTS=['alarm_set','alarm_remove','alarm_query'];TAGS=['O','B-time','I-time','B-date','I-date','B-general_frequency','I-general_frequency']
class NLU(nn.Module):
 def __init__(self):
  super().__init__();self.embedding=nn.Embedding(256,48);self.gru=nn.GRU(48,128,batch_first=True);self.intent=nn.Linear(128,3);self.slot=nn.Linear(128,7)
 def forward(self,x,lengths):
  z,_=self.gru(self.embedding(x));last=z[torch.arange(len(lengths)),lengths-1];return self.intent(last),self.slot(z)
def infer(m,text):
 b=text.encode()
 if not b or len(b)>256:return {'rejected':'empty_or_over256bytes'}
 with torch.no_grad():
  i,s=m(torch.tensor([list(b)]),torch.tensor([len(b)]));return {'intent':INTENTS[int(i.argmax(-1)[0])],'intent_probabilities':i.softmax(-1)[0].tolist(),'byte_tags':s.argmax(-1)[0].tolist(),'tag_names':TAGS}
