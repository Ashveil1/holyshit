import sys,json,argparse,torch
from model import NLU,infer
p=argparse.ArgumentParser();p.add_argument('--weights',required=True);a=p.parse_args();torch.set_num_threads(1);m=NLU();state=torch.load(a.weights,weights_only=False,map_location='cpu');m.load_state_dict(state['model']if 'model'in state else state);m.eval()
for line in sys.stdin:
 r=json.loads(line);print(json.dumps({'id':r.get('id'),'prediction':infer(m,r['text'])},ensure_ascii=False),flush=True)
