"""Read-only NLU-to-frame adapter. No semantic time parser, no learned dialogue.
Raw slot strings only. No target IDs exist, so remove ALWAYS asks for target.
No controls/negation detector is claimed: confirm/cancel are explicit UI controls.
"""
from model import infer,TAGS
from dialogue_policy import Policy
class Session:
 def __init__(self,model,operating_point):self.model=model;self.op=operating_point;self.policy=Policy()
 def control(self,value):
  if value not in ['confirm','cancel']:raise ValueError('unknown UI control')
  return self.policy.step({'control':value})
 def text(self,text):
  z=infer(self.model,text)
  if 'rejected'in z:return self.policy.step({'accepted':False})
  conf=max(z['intent_probabilities']);accepted=self.op['pass']and z['intent']!='other'and conf>=self.op['selected']['threshold'];spans=[];active=None;illegal=False
  for i,t in enumerate(z['char_tags']):
   if t==0:
    if active:spans.append(active);active=None
   elif t%2==1:
    if active:spans.append(active)
    active={'kind':TAGS[t][2:],'start':i,'end':i+1}
   else:
    kind=TAGS[t][2:]
    if not active or active['kind']!=kind:illegal=True
    else:active['end']=i+1
  if active:spans.append(active)
  slots={};counts={}
  for s in spans:
   kind=s['kind'];counts[kind]=counts.get(kind,0)+1;slots[kind]=text[s['start']:s['end']]
  ambiguous=illegal or any(v>1 for v in counts.values())
  # Raw predicted strings are not parsed/validated dates or times and never execution parameters.
  frame={'accepted':bool(accepted),'intent':z['intent'],'slots':slots,'ambiguous':ambiguous,'raw_slot_text_only':True}
  response=self.policy.step(frame);return {**response,'nlu':z,'raw_frame':frame,'limitations':['No semantic negation detection','No time/date grounding','No followup slot merge','Removal target unsupported: always clarify','Confirm/cancel are UI controls, not language understanding']}
