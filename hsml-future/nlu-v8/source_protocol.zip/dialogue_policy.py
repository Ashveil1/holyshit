"""Programmed simulation policy, not learned NLU and never an alarm executor.
NLU produces frames. No confidence threshold is implemented until frozen calibration.
Pending frames are not executable. All outputs explicitly say simulation_only.
"""
from dataclasses import dataclass,field
@dataclass
class Policy:
 pending:dict|None=None
 def step(self,frame):
  if frame.get('control')=='cancel':self.pending=None;return self.out('cancelled')
  if frame.get('control')=='confirm':
   if not self.pending or not self.pending.get('complete'):return self.out('nothing_to_confirm')
   result=self.pending;self.pending=None;return self.out('simulated_confirmation',frame=result)
  if not frame.get('accepted',False)or frame.get('intent')in [None,'other']:
   self.pending=None;return self.out('unsupported_or_uncertain')
  intent=frame['intent'];slots=dict(frame.get('slots',{}))
  # State merging intentionally not automatic: corrections require a complete new frame.
  if frame.get('ambiguous')or frame.get('negated'):
   self.pending=None;return self.out('clarify_interpretation')
  required={'alarm_set':['time'],'alarm_remove':['target'],'alarm_query':[]}
  if intent not in required:self.pending=None;return self.out('unsupported_or_uncertain')
  missing=[k for k in required[intent]if not slots.get(k)]
  self.pending={'intent':intent,'slots':slots,'complete':not missing}
  return self.out('ask_missing'if missing else'ask_confirmation',missing=missing,frame=self.pending)
 def out(self,status,**details):return {'status':status,'simulation_only':True,'external_action':False,**details}
if __name__=='__main__':
 p=Policy();assert p.step({'accepted':True,'intent':'alarm_set'})['status']=='ask_missing';assert p.step({'control':'confirm'})['status']=='nothing_to_confirm';assert p.step({'accepted':True,'intent':'alarm_set','slots':{'time':'07:00'}})['status']=='ask_confirmation';assert p.step({'control':'cancel'})['status']=='cancelled';assert p.step({'control':'confirm'})['status']=='nothing_to_confirm';assert p.step({'accepted':False,'intent':'alarm_set','slots':{'time':'07:00'}})['status']=='unsupported_or_uncertain';print('6 semantic-frame policy unit assertions passed, NOT end-to-end text/dialogue accuracy')
