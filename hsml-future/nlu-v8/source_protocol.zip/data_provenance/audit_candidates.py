import duckdb,json,re,hashlib,collections
from pathlib import Path
P=Path(__file__).resolve().parent;c=duckdb.connect();c.execute("SET memory_limit='64MB'");c.execute('SET threads=1');src=P/'massive-th-train.parquet';names=json.loads(Path('/home/sandbox/hsml-future-nlu-rerun/data/source_features.json').read_text())['info']['features']['intent']['names'];seen=set();rows=[];rej=collections.Counter()
for id,utt,ann,intent,scenario in c.execute('select id,utt,annot_utt,intent,scenario from read_parquet(?) order by cast(id as int)',[str(src)]).fetchall():
 if intent in [48,52,23]:continue
 if not utt or len(utt.encode())>256:rej['length']+=1;continue
 norm=re.sub(r'\s+','',utt).lower()
 if norm in seen:rej['normalized_duplicate']+=1;continue
 seen.add(norm);family=re.sub(r'\[([^:\[\]]+) : ([^\[\]]*)\]',lambda m:'{'+m[1].strip()+'}',ann);recon=re.sub(r'\[([^:\[\]]+) : ([^\[\]]*)\]',lambda m:m[2],ann)
 if recon!=utt:rej['annotation_mismatch']+=1;continue
 family=re.sub(r'\s+','',family).lower();h=hashlib.sha256(family.encode()).hexdigest();bucket=int(h[:8],16)%10;split='dev'if bucket<2 else'calibration'if bucket<4 else'train';rows.append({'id':id,'utt':utt,'intent_source_id':intent,'intent_source':names[intent],'scenario_source_id':scenario,'intent':'other','intent_target':3,'template_group':h,'split':split,'source_partition':'train','spans':[],'byte_tags':[0]*len(utt.encode())})
# Exact cap per source class after deterministic family assignment; do not cross family boundaries.
selected=[];counts=collections.Counter()
for r in sorted(rows,key=lambda r:hashlib.sha256(('v7-negative-cap:'+r['id']).encode()).hexdigest()):
 k=(r['split'],r['intent_source_id']);cap=6 if r['split']=='train'else 2
 if counts[k]<cap:selected.append(r);counts[k]+=1
for split in ['train','dev','calibration']:
 rr=[r for r in selected if r['split']==split];(P/('negative_'+split+'.jsonl')).write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n'for r in rr))
summary={'status':'CANDIDATE_NOT_FROZEN','source_url':'https://huggingface.co/datasets/AmazonScience/massive/resolve/ed58ac423a2f4121720918bf5301577edce4ffd3/th-TH/train/0000.parquet','sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'license':'CC-BY-4.0','exact_utt_unchanged':True,'negative_definition':'All official non-alarm intents; other slot labels masked/not transferred to alarm slots; source annotations retained for family grouping only','rejections':dict(rej),'candidate_pool':len(rows),'negative_sources':[{'id':i,'name':n,'eligible':sum(r['intent_source_id']==i for r in rows),'selected':{s:counts[(s,i)]for s in ['train','dev','calibration']}}for i,n in enumerate(names)if i not in[48,52,23]],'counts':dict(collections.Counter(r['split']for r in selected)),'template_families':{s:sorted(set(r['template_group']for r in selected if r['split']==s))for s in ['train','dev','calibration']},'files':{p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in P.glob('negative_*.jsonl')},'family_split_rule':'delexicalized annotations, remove whitespace/lower for GROUPING ONLY; sha256 first8 mod10:0,1DEV;2,3cal;4..9train; per-intent cap6/2/2 by sha256(v7-negative-cap:sourceID)','not_fresh_generalization':'Source officialTRAIN has been inspected. Reviewer future acceptance must remain independently held and exclude union of listed families/normalized texts.'}
(P/'negative_audit.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in summary.items()if k not in ['negative_sources','template_families']},indent=2))
