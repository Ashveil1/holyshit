"""Deterministic TRAIN-only ASCII U+0020 removal. No generated text/labels.
Preserve source family/split; remap each retained Unicode codepoint and source span.
"""
from pathlib import Path
import json,hashlib,collections
P=Path(__file__).resolve().parent;rs=list(map(json.loads,(P/'v7_candidate_train.jsonl').read_text().splitlines()));out=[];skipped=collections.Counter()
for r in rs:
 out.append(dict(r,variant='original'));text=r['utt'];new=''.join(c for c in text if c!=' ')
 if new==text:skipped['unchanged']+=1;continue
 offsets=[0]
 for c in text:offsets.append(offsets[-1]+int(c!=' '))
 spans=[];tags=[0]*len(new.encode())
 for sp in r['spans']:
  a=offsets[sp['start_char']];b=offsets[sp['end_char']];v=new[a:b];assert v==sp['text'].replace(' ','')
  if not v:raise ValueError('empty transformed gold slot')
  ns={**sp,'start_char':a,'end_char':b,'text':v,'start_byte':len(new[:a].encode()),'end_byte':len(new[:b].encode())};spans.append(ns);k=['time','date','general_frequency'].index(sp['slot']);tags[ns['start_byte']]=1+2*k
  for i in range(ns['start_byte']+1,ns['end_byte']):tags[i]=2+2*k
 for sp in spans:assert new[sp['start_char']:sp['end_char']]==sp['text']and new.encode()[sp['start_byte']:sp['end_byte']].decode()==sp['text']
 out.append({**r,'utt':new,'annot_utt':None,'spans':spans,'byte_tags':tags,'variant':'ascii_space_removed','original_id':r['id'],'original_utt_sha256':hashlib.sha256(text.encode()).hexdigest(),'transform':'Remove Unicode U+0020 only; codepoint-index map; recompute source-derived BIO span byte positions','char_boundary_map':offsets})
# Duplicated derived texts must not overcount evidence; conflicting source labels fail closed.
seen={};clean=[];dups=0
for r in out:
 k=(r['utt'],r['intent'])
 if k in seen:dups+=1;continue
 seen[k]=True;clean.append(r)
p=P/'v7_augmented_train.jsonl';p.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n'for r in clean));report={'status':'DRAFT_NOT_FROZEN','base_rows':len(rs),'output_rows':len(clean),'transformed_rows':sum(r['variant']!='original'for r in clean),'skips':dict(skipped),'duplicate_derived_removed':dups,'transform_source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'output_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'counts':dict(collections.Counter(r['intent']for r in clean)),'dev_cal_unchanged':True,'source_lineage_retained':True,'mechanical_alignment_assertions_passed':True,'sampling_caveat':'Uniform row sampling duplicates space-containing source rows across ALL four classes; exposure counters must report original sourceID counts and variant examples, not independent data.'};(P/'augmentation_audit.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
