import json,re,hashlib,collections
from pathlib import Path
P=Path(__file__).resolve().parent;O=Path('/home/sandbox/hsml-future-nlu-rerun/data');positives=[json.loads(l)for n in ['train','dev']for l in (O/(n+'.jsonl')).read_text().splitlines()];negatives=[json.loads(l)for n in ['train','dev','calibration']for l in (P/('negative_'+n+'.jsonl')).read_text().splitlines()];by=collections.defaultdict(list)
for r in positives+negatives:
 r=dict(r);bucket=int(r['template_group'][:8],16)%10;r['split']='dev'if bucket<2 else'calibration'if bucket<4 else'train';r['slot_loss_enabled']=r['intent']!='other';by[re.sub(r'\s+','',r['utt']).lower()].append(r)
clean=[];conflicts=[]
for key,rs in by.items():
 if len({r['intent']for r in rs})>1:conflicts.append({'ids':[r['id']for r in rs],'intents':[r['intent']for r in rs]});continue
 clean.append(rs[0])
fam={s:set(r['template_group']for r in clean if r['split']==s)for s in ['train','dev','calibration']};norm={s:set(re.sub(r'\s+','',r['utt']).lower()for r in clean if r['split']==s)for s in fam};assert all(not(fam[a]&fam[b])and not(norm[a]&norm[b])for a in fam for b in fam if a!=b)
for s in fam:(P/('v7_candidate_'+s+'.jsonl')).write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n'for r in sorted(clean,key=lambda r:int(r['id']))if r['split']==s))
r={'status':'CANDIDATE_NOT_FROZEN_NO_AUGMENTATION','counts':{s:dict(collections.Counter(r['intent']for r in clean if r['split']==s))for s in fam},'cross_label_normalized_conflicts':conflicts,'normalized_text_overlap':0,'template_family_overlap':0,'families':{s:sorted(v)for s,v in fam.items()},'hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in P.glob('v7_candidate_*.jsonl')},'slot_loss':'OTHER rows MASKED entirely; no slot O targets learned from negative rows','caveat':'Positive source union312 was all examined previously; reused as development/model selection/calibration only, not fresh test.'};(P/'combined_audit.json').write_text(json.dumps(r,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in r.items()if k!='families'},ensure_ascii=False,indent=2))
